import React from 'react';
import axios from 'axios';
import {BrowserRouter, Routes, Route} from 'react-router-dom';
import Login from '../login_signup/Login';
import Home from './Home';
import Navbar from '../navbar/Navbar';
import {Cards} from '../cards/Cards';

function App() {

  axios.interceptors.request.use(async (config) => {
    config.headers["projectid"] = "f104bi07c490";
    return config;
  });

  return (<>
      <div className='h-screen w-full'>
      <BrowserRouter>
      
        <Routes>
          <Route path="/" element={<Login/>}/>
          <Route path="/home" element={<Home/>}/>
          <Route path="/cards" element={<Cards/>}/>
        </Routes>
      </BrowserRouter>
      </div>
  </>)
}

export default App;
