import React, {useState, useEffect} from 'react';
import axios from 'axios';
// import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from '../navbar/Navbar';

const Home = () => {

    const [post, setPost] = useState([]);

    const userPost = async () =>{
        axios.get('https://academics.newtonschool.co/api/v1/facebook/post').then((response)=>{
            console.log(response.data.data)
            setPost(response.data.data)
        }).catch((error)=>{
            console.log(error);
        })
    }
    useEffect (()=>{
        userPost()
    },[])

    return (<>
        {/* <div className='bg-[#F0F2F5] w-full h-screen'> */}
            <Navbar />
            <div className="w-full h-full flex">
                <div className='basis-1/4   bg-gray-300'> part 1
                    {/* Content for the first part */}
                </div>
                <div className="basis-3/5  bg-green-300">
                    {post?.map((obj, _id)=>{
                        return (
                            <div key={obj._id}>
                                <h3>{obj.author.name}</h3>
                                <h3><img src={obj.images}></img></h3>   
                                <h3>{obj.likeCount}</h3>   
                            </div>
                        )
                    })}
                </div>
                <div className="basis-1/4  bg-blue-500">part 3
                    {/* Content for the third part */}
                </div>
            </div>
        {/* </div> */}
    </>
    )
}

export default Home
